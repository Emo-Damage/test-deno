# vless-js

This library was generated with [Nx](https://nx.dev).

## Building

Run `nx build vless-js` to build the library.

## Running unit tests

Run `nx test vless-js` to execute the unit tests via [Jest](https://jestjs.io).
