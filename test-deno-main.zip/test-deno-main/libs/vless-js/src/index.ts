export {
  delay,
  makeReadableWebSocketStream,
  closeWebSocket,
  processVlessHeader,
} from './lib/vless-js';
